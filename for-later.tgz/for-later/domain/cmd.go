package domain

import (
	"github.com/gd-tools/gd-tools/config"
	"github.com/urfave/cli/v2"
)

var Describe = `The domain command handles email domains.`

var Command = &cli.Command{
	Name:        "domain",
	Usage:       "Handle email domains (see 'account' for email users)",
	Description: Describe,
	Flags: []cli.Flag{
		config.FlagVerbose,
	},
	Subcommands: []*cli.Command{
		AliasCommand,
		CAACommand,
		// DeployCommand,
		ListCommand,
		SPFCommand,
		SyncCommand,
	},
	Action: ListRun,
}
