package config

import (
	"github.com/gd-tools/gd-tools/agent"
	"github.com/gd-tools/gd-tools/assets"
	"github.com/gd-tools/gd-tools/utils"
)

func (cfg *Config) DeployFilesystem() error {
	cfg.Debug("Enter config/filesystem.go")

	cfg.Debug("genrating DH-Parameters")
	dhBytes, err := utils.GenerateDHParams(2048)
	if err != nil {
		return err
	}

	req := cfg.NewRequest()

	vmailUser := agent.User{
		Name:    "vmail",
		Comment: "Virtual Mail User",
		System:  true,
		Shell:   "/usr/sbin/nologin",
	}
	req.Users = append(req.Users, &vmailUser)

	dataMkdir := agent.File{
		Task:  "mkdir",
		Path:  assets.GetToolsDir("data"),
		Mode:  "0755",
		User:  "root",
		Group: "root",
	}
	req.AddFile(&dataMkdir)

	certsMkdir := agent.File{
		Task:  "mkdir",
		Path:  assets.GetToolsDir("data", "certs"),
		Mode:  "0755",
		User:  "root",
		Group: "root",
	}
	req.AddFile(&certsMkdir)

	hooksMkdir := agent.File{
		Task:  "mkdir",
		Path:  assets.GetToolsDir("data", "hooks"),
		Mode:  "0755",
		User:  "root",
		Group: "root",
	}
	req.AddFile(&hooksMkdir)

	vmailMkdir := agent.File{
		Task:  "mkdir",
		Path:  assets.GetToolsDir("data", "vmail"),
		Mode:  "0755",
		User:  "vmail",
		Group: "vmail",
	}
	req.AddFile(&vmailMkdir)

	logsMkdir := agent.File{
		Task:  "mkdir",
		Path:  assets.GetToolsDir("logs"),
		Mode:  "0755",
		User:  "root",
		Group: "root",
	}
	req.AddFile(&logsMkdir)

	sshMkdir := agent.File{
		Task:  "mkdir",
		Path:  assets.GetRootDir(".ssh"),
		Mode:  "0700",
		User:  "root",
		Group: "root",
	}
	req.AddFile(&sshMkdir)

	dhFile := agent.File{
		Task:    "write",
		Path:    cfg.DHParamsPath(),
		Content: dhBytes,
		Mode:    "0644",
		User:    "root",
		Group:   "root",
	}
	req.AddFile(&dhFile)

	if err := req.Send(); err != nil {
		return err
	}

	cfg.Debug("Leave config/filesystem.go")
	return nil
}
