package config

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/gd-tools/gd-tools/agent"
	"github.com/gd-tools/gd-tools/assets"
)

func LoadRustDesk() (*agent.RustDesk, error) {
	content, err := os.ReadFile(agent.RustDeskFile)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil // RustDesk is not installed
		}
		return nil, fmt.Errorf("failed to read %s: %w", agent.RustDeskFile, err)
	}

	var rd agent.RustDesk
	if err := json.Unmarshal(content, &rd); err != nil {
		return nil, fmt.Errorf("failed to unmarshal %s: %w", agent.RustDeskFile, err)
	}

	return &rd, nil
}

func (cfg *Config) DeployRustDesk(rd *agent.RustDesk) error {
	if rd == nil {
		return fmt.Errorf("missing RustDesk pointer")
	}
	cfg.Debug("Enter config/rustdesk.go")

	_, rdRel, err := cfg.Catalog.Get("rustdesk", rd.Version)
	if err != nil {
		return err
	}
	if rdRel.Download.Directory == "" {
		return fmt.Errorf("missing Directory in RustDesk download")
	}
	rd.Download = &rdRel.Download

	if err := cfg.RustDeskUser(rd); err != nil {
		return err
	}

	if err := cfg.RustDeskDownload(rd); err != nil {
		return err
	}

	if err := cfg.RustDeskExtract(rd); err != nil {
		return err
	}

	if err := cfg.RustDeskService(rd); err != nil {
		return err
	}

	if err := cfg.RustDeskKeys(rd); err != nil {
		return err
	}

	if err := cfg.RustDeskFirewall(rd); err != nil {
		return err
	}

	if status, err := cfg.SetCNAME(rd.DomainName, rd.HostName); err != nil {
		return err
	} else if status != "" {
		cfg.Say(status)
	}

	cfg.Debug("Leave config/rustdesk.go")
	return nil
}

func (cfg *Config) RustDeskUser(rd *agent.RustDesk) error {
	req := cfg.NewRequest()

	rustdeskUser := agent.User{
		Name:    "rustdesk",
		Comment: "RustDesk Server User",
		System:  true,
		HomeDir: rd.DataDir(),
		Shell:   "/usr/sbin/nologin",
	}
	req.Users = append(req.Users, &rustdeskUser)

	dataMkdir := agent.File{
		Task:  "mkdir",
		Path:  rd.DataDir(),
		Mode:  "0750",
		User:  "rustdesk",
		Group: "rustdesk",
	}
	req.AddFile(&dataMkdir)

	logsMkdir := agent.File{
		Task:  "mkdir",
		Path:  rd.LogsDir(),
		Mode:  "0750",
		User:  "rustdesk",
		Group: "rustdesk",
	}
	req.AddFile(&logsMkdir)

	if err := req.Send(); err != nil {
		return err
	}
	return nil
}

func (cfg *Config) RustDeskDownload(rd *agent.RustDesk) error {
	req := cfg.NewRequest()

	req.Downloads = append(req.Downloads, rd.Download)

	if err := req.Send(); err != nil {
		return err
	}
	return nil
}

func (cfg *Config) RustDeskExtract(rd *agent.RustDesk) error {
	req := cfg.NewRequest()

	extract := agent.File{
		Task:   "extract",
		Path:   assets.GetDownloadsDir(rd.Download.Filename),
		Target: rd.DataDir(),
		Mode:   "0750",
		User:   "rustdesk",
		Group:  "rustdesk",
	}
	req.AddFile(&extract)

	if err := req.Send(); err != nil {
		return err
	}

	return nil
}

func (cfg *Config) RustDeskService(rd *agent.RustDesk) error {
	req := cfg.NewRequest()

	hbbsTmpl, err := assets.Render("rustdesk/hbbs.service", rd)
	if err != nil {
		return err
	}
	hbbsFile := agent.File{
		Task:    "write",
		Path:    assets.GetEtcDir("systemd", "system", "rustdesk-hbbs.service"),
		Content: hbbsTmpl,
		Mode:    "0644",
		Service: "rustdesk-hbbs",
	}
	req.AddFile(&hbbsFile)

	hbbrTmpl, err := assets.Render("rustdesk/hbbr.service", rd)
	if err != nil {
		return err
	}
	hbbrFile := agent.File{
		Task:    "write",
		Path:    assets.GetEtcDir("systemd", "system", "rustdesk-hbbr.service"),
		Content: hbbrTmpl,
		Mode:    "0644",
		Service: "rustdesk-hbbr",
	}
	req.AddFile(&hbbrFile)

	if err := req.Send(); err != nil {
		return err
	}

	return nil
}

func (cfg *Config) RustDeskKeys(rd *agent.RustDesk) error {
	req := cfg.NewRequest()

	req.RustDesk = rd

	if err := req.Send(); err != nil {
		return err
	}

	return nil
}

func (cfg *Config) RustDeskFirewall(rd *agent.RustDesk) error {
	cfg.AddFirewall("21115/tcp")
	cfg.AddFirewall("21116/tcp")
	cfg.AddFirewall("21116/udp")
	cfg.AddFirewall("21117/tcp")
	if err := cfg.Save(); err != nil {
		return err
	}

	req := cfg.NewRequest()
	req.AddFirewall("21115/tcp")
	req.AddFirewall("21116/tcp")
	req.AddFirewall("21116/udp")
	req.AddFirewall("21117/tcp")
	if err := req.Send(); err != nil {
		return err
	}

	return nil
}
